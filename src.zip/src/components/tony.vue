<template>
    <div>
<!--      <h2 class="section-title">学习经历</h2>-->
      <div class="container-sm">
        <h2>Tony Brown</h2>
        <strong>国际合作带头人</strong>
        <p>
          职称：教授 <br>
          研究领域：艺术与设计教育研究
        </p>
        <strong>学习经历</strong>
        <p>
          1971-1975 加拿大曼尼托巴大学 荣誉学士<br>
          1975-1976 加拿大诺瓦艺术与设计大学 硕士<br>
          1977-1978 加拿大康考迪亚大学 硕士<br>
        </p>
        <strong>代表著作</strong>
        <table>
          <tr>
            <td>序号</td><td>本人排序</td><td>年份</td><td>著作名称</td>
            <td>出版单位</td>
          </tr>
          <tr>
            <td>1</td><td>1</td><td>1996</td><td>Downtime</td><td>Witte de With, Rotterdam, Holland</td>
          </tr>
          <tr>
            <td>2</td><td>2</td><td>1981</td><td>Correspondences</td>
            <td>The Walter Philipps Gallery,Banff Center, Canada</td>
          </tr>
          <tr>
            <td>3</td><td>3</td><td>1986</td><td>Space Invaders</td><td>The Mackenzie Art Gallery, Canada</td>
          </tr>
        </table>
        <strong>代表论文</strong>
        <table>
          <tr>
            <td>序号</td><td>本人排序</td><td>年份</td><td>题目</td><td>期刊名称</td>
          </tr>
          <tr>
            <td>1</td><td>1</td><td>2019</td><td>“时代新象”2019中国景德镇“陶溪川”公共雕塑国际大展</td>
            <td>景德镇陶溪川美术馆</td>
          </tr>
          <tr>
            <td>2</td><td>2</td><td>2019</td><td>第二届平遥国际雕塑节</td><td>平遥国际雕塑节</td>
          </tr>
          <tr>
            <td>3</td><td>5</td><td>2017</td><td>“白光/白音”——谭平/托尼·布朗</td><td>元典美术馆</td>
          </tr>
          <tr>
            <td>4</td><td>3</td><td>2016</td><td>第三届今日文献展</td><td>今日美术馆</td>
          </tr>
          <tr>
            <td>5</td><td>4</td><td>2016</td><td>“造·画”——托尼·布朗与隋建国</td><td>艺术8</td>
          </tr>
        </table>
        <strong>主持的科研项目</strong>
        <table>
          <tr>
            <td>序号</td><td>起始时间</td><td>结束时间</td><td>项目名称</td><td>项目性质及来源</td><td>项目经费</td>
          </tr>
          <tr>
            <td>1</td><td>1997</td><td>1998</td><td>Digital Imaging across Art, Architecture and Science<br>跨艺术、建筑和科学的数字影像研究</td>
            <td>政府项目； 法国国立马赛美术学院&欧洲核子研究理事会</td><td>政府经费</td>
          </tr>
          <tr>
            <td>2</td><td>1995</td><td>1998</td><td>3D Digital Imaging for Engineering Production and Research<br>  工程与生产领域的3D数字影像研究</td>
            <td>政府项目； 法国国立巴黎矿业工程学院</td><td>政府经费</td>
          </tr>
          <tr>
            <td>3</td><td>1998</td><td>1999</td><td>From Analogue to Digital Research and Production</td><td>政府项目； 法国国家当代艺术</td><td>政府经费</td>
          </tr>
          <tr>
            <td></td><td></td><td></td><td>从模拟到数字的研究与创作</td> <td>工作室</td><td></td>
          </tr>
        </table>

        <strong>获奖情况</strong>
        <table>
          <tr>
            <td>序号</td><td>本人排序</td><td>年份</td><td>奖励名称</td><td>授奖单位</td><td>奖励级别</td>
          </tr>
          <tr>
            <td>1</td><td>1</td><td>1992</td><td>Senior Arts Grant <br>高级艺术奖金</td><td>Canada council for the arts加拿大国家艺术委员会</td>
            <td>National <br>国家级</td>
          </tr>
          <tr>
            <td>2</td><td>2</td><td>2005</td><td>Art Project Award <br>艺术项目奖金</td> <td>Fonds National d'Art Contemporain, Paris, France 法国国家当代艺术基金会</td>
            <td>National <br>国家级</td>
          </tr>
          <tr>
            <td>3</td><td>3</td><td>1983、1985/1989</td><td>Arts Award <br>艺术奖金</td><td>Canada council for the arts加拿大国家艺术委员会</td> <td>National <br>国家级</td>
          </tr>
        </table>
        <strong>学术兼职 </strong>
        <p>
          1995-1998年，兼任法国国立巴黎矿业工程学院新媒体系客座教授，指导研究生和博士生。(Ecole nationale supérieure des Mines de Paris)
          <br><br>
          1997-1998年，兼任法国国立马赛美术学院（Ecole Nationale des beaux-arts,Marseille）新媒体系客座教授、研究生导师，期间作为联合主持者参与欧洲核子研究理事会（CERN）的多项研究项目。
          <br><br>
          1998-1999年，兼任法国国家当代艺术工作室客座教授、研究生导师。（Studio National des Arts Contemporains）
          <br><br>
          2009-2011年，兼任美国帕森斯艺术设计学院巴黎分院教务院长。（Parson Paris school of art and design）
          <br><br>
          2010-2020年，兼任中央美术学院国际预科学术总监（International Foundation Course Program, CAFA）
          <br><br>
          2011-2020年,兼任西安欧亚学院国际学术顾问（EAaD, Xi’an Eurasia University）
        </p>
        <strong>学术交流</strong>
        <p>
          在近40年的学术生涯中曾受邀在全球众多大学和艺术院校讲座授课，拥有深度学术交往与合作的院校和机构主要有： <br>
          -	英国皇家艺术学院（Royal College of Art, London, UK）<br>
          -	德国柏林艺术大学（The Universität der Künste Berlin (UdK)）<br>
          -	德国ZKM艺术媒体中心（The ZKM | Center for Art and Media）<br>
          -	荷兰阿姆斯特丹皇家视觉艺术学院 (The Rijksakademie vanBeeldendeKunsten)<br>
          -	美国卡内基·梅隆大学（Carnegie Mellon University）<br>
          -	加拿大艾米丽卡艺术设计大学（Emily Carr University of Art and Design）<br>
          -	加拿大维多利亚大学（University of  Victoria）<br>
          -	加拿大康考迪亚大学（Concordia University）<br>
          -	加拿大约克大学（York University）<br>
          -	意大利威尼斯大学（Ca’foscari University of Venice）<br>
          -	荷兰威廉德库宁学院（The Willem de Kooning Academy）<br>
          -	韩国艺术综合大学（Korea National University of Arts）<br>
          -	日本NTT新媒体艺术中心（NTT InterCommunication Center [ICC]）<br>
          -	新加坡拉萨尔艺术学院（LASALLE College of the Arts）<br>
          -	巴西圣保罗大学（University of São Paulo）<br>
          -	哥伦比亚国立大学（Universidad Nacional de Colombia, Fine Arts and Visual Arts Bogota）<br>
          -	印度艾哈迈达巴德国家设计学院（National institute of design Ahmedabad）<br>
          -	香港大学（The University of Hong Kong）<br>
        </p>

      </div>
    </div>
</template>

<script>
    export default {
        name: "gaopeng"
    }
</script>

<style scoped>
  table{text-align: center;border-collapse: collapse;width: 100%;margin: 20px 0;}
  td{padding: 10px;border: #000 solid 1px;}
</style>
