<template>
    <div>
<!--      <h2 class="section-title">学习经历</h2>-->
      <div class="container-sm">
        <h2>叶锦添</h2>
        <p>
          特聘教授 <br>
          电影艺术指导、服装设计师、视觉艺术家，“新东方主义”美学概念推行者
        </p>
        <strong>曾获奖项：</strong>
        <p>
          奥斯卡“最佳艺术指导”、英国电影学院“最佳服装设计”、台湾电影金马奖“最佳美术设计”和“最佳造型设计”、香港电影金像奖“最佳美术指导”和“最佳服装造型设计”
        </p>
        <strong>代表著作：</strong>
        <strong>艺术指导：</strong>
        <p>
          卧虎藏龙》《你那边几点》《小城之春》《恋爱中的宝贝》《被遗忘的天使》《赤壁（上）》《赤壁（下）》
        </p>
        <strong>服装设计：</strong>
        <p>
          《卧虎藏龙》《双瞳》《小城之春》《天堂口》《赤壁（上）》《赤壁（下）》《风声》《一九四二》《橘子红了》《康定情歌》《红楼梦》（2010）《那年花开月正圆》
        </p>
        <strong>美术设计</strong>
        <p>
          《英雄本色》《诱僧》《阿婴》《双瞳》《夜宴》《红楼梦》（2010）
        </p>
        <strong>舞台服饰</strong>
        <p>
          云门舞集《焚松》《太阳悬止时》 <br>
          无垢舞团《醮》《花神祭》<br>
          汉唐乐府《艳歌行》《俪人行》《荔镜奇缘》《梨园幽梦》<br>
          台北越界舞团《天国出走》《蚀》《骚动的灵魂-天堂鸟》<br>
          优剧场《云脚台湾》《海朝音》<br>
          当代传奇剧场《楼兰女》《奥瑞斯提亚》<br>
          复兴剧团《罗生门》<br>
          太古踏舞团《生之曼陀罗》《诗与花的独言》<br>
          光环舞集《移植》<br>
          江之翠南管实验剧团《南管游赏》<br>
          香港城市当代舞团《创世纪》<br>
          新古典舞团《曹丕与甄宓》、《黑洞》<br>
          香港话剧团《情话紫钗》<br>
          赖声川话剧《如梦之梦》<br>
        </p>
        <strong>书籍：</strong>
        <table>
          <tr>
            <td>时间</td><td>书名</td><td>出版社</td>
          </tr>
          <tr>
            <td>2008年7月</td><td>《赤壁-美术笔记》</td><td>当代中国出版社</td>
          </tr>
          <tr>
            <td>2010年1月</td><td>《神思陌路：叶锦添的创意美学》</td><td>中国旅游出版社</td>
          </tr>
          <tr>
            <td>2016年11月</td><td>《叶锦添的创意美学:流形》</td><td>新星出版社</td>
          </tr>
        </table>

      </div>
    </div>
</template>

<script>
    export default {
        name: "gaopeng"
    }
</script>

<style scoped>
  table{text-align: center;border-collapse: collapse;width: 100%;margin: 20px 0;}
  td{padding: 10px;border: #000 solid 1px;}
</style>
