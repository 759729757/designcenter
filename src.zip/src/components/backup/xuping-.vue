<template>
    <div>
<!--      <h2 class="section-title">学习经历</h2>-->
      <div class="container-sm">
        <h2>许平</h2>
        <strong>设计理论带头人</strong>
        <p>
          职称：教授 <br>
          研究领域：设计史及设计教育研究
        </p>
        <strong>学习经历</strong>
        <p>
          1984-1987南京艺术学院工艺美术系 硕士 <br>
          1988-1991南京艺术学院美术系 博士<br>
          1991-1992  日本爱知县立艺术大学美术学部研修<br>
        </p>
        <strong>代表著作</strong>
        <table>
          <tr>
            <td>序号</td><td>本人排序</td><td>年份</td><td>著作名称</td>
            <td>出版单位</td>
          </tr>
          <tr>
            <td>1</td><td>1</td><td>2014</td><td>《设计的大地》（论文集）</td><td>北京大学出版社</td>
          </tr>
          <tr>
            <td>2</td><td>1</td><td>2013</td><td>《设计教育：中国高等设计教育版图（2007--2012）》</td>
            <td>河北教育出版社</td>
          </tr>
          <tr>
            <td>3</td><td>独立</td><td>2010</td><td>《青山看我》（论文集）</td><td>重庆大学出版社</td>
          </tr>
        </table>
        <strong>近五年发表主要论文</strong>
        <table>
          <tr>
            <td>序号</td><td>本人排序</td><td>年份</td><td>题目</td><td>期刊名称</td><td>卷期</td>
            <td>页码</td><td>收录类型 <br>（区分）</td>
          </tr>
          <tr>
            <td>1</td><td>独立</td><td>2020</td><td>《百年归程：孙中山〈建国方略〉中的“设计”描述》</td>
            <td>《装饰》</td><td>2020/4</td><td></td><td>CSSCI 来源</td>
          </tr>
          <tr>
            <td>2</td><td>独立</td><td>2020</td><td>《融入民艺大地的迎春山花 ——忆廉老师》</td><td>《民艺》</td>
            <td>2020/2</td><td></td><td>/</td>
          </tr>
          <tr>
            <td>3</td><td>1</td><td>2020</td><td>《中国民艺学的旗帜》</td><td>《民艺》</td><td>2020/1</td><td></td><td>/</td>
          </tr>
          <tr>
            <td>4</td><td>1</td><td>2020</td><td>重回垃圾分类生态的良性牡循环</td><td>《美术观察》</td><td>2020/9</td><td></td><td>国家级艺术类核心期刊</td>
          </tr>


		  <tr>
            <td>5</td><td>独立</td><td>2020</td><td>重归情景与景观化的设计现实——从包豪斯到“情境主义”的社会批判</td><td>《美术研究》</td><td>2015/02</td><td></td><td>CSSCI来源</td>
          </tr>
		  <tr>
            <td>6</td><td>1</td><td>2020</td><td>一组不能忘记的历史影像——中共早期革命活动中的平面设计人和事</td><td>《艺术设计研究》</td><td>2015/01</td><td></td><td>CSSCI来源</td>
          </tr>
        </table>
        <strong>主持的科研项目</strong>
        <table>
          <tr>
            <td>序号</td><td>起始时间</td><td>结束时间</td><td>项目名称</td><td>项目性质及来源</td><td>项目经费</td>
          </tr>
          <tr>
            <td>1</td><td>2020/9</td><td></td><td>“一带一路”背景下的国家设计政策研究</td><td>教育部艺术学重大项目</td><td>60万元</td>
          </tr>
		   <tr>
            <td>2</td><td>2010</td><td>2015</td><td>民族传统文化元素在现代艺术设计中的应用研究</td><td>教育部哲学社会科学重大课题攻关</td><td>76万元</td>
          </tr>
        </table>

        <strong>获奖情况</strong>
        <p>
          2008年获北京奥运会组委会“工作表彰”奖
        </p>
        <strong>学术兼职</strong>
        <p>
		·历任教育部、国务院学位委员会第六届（艺术学）学科评议组成员、（设计学）临时学科组成员，第七届（设计学）学科评议组成员、召集人（2009至今）<br>
		·教育部“长江学者奖励计划”终审专家<br>
		·教育部哲学社会科学基金重大攻关项目、教育部人文社科基金艺术学规划项目重大课题终审专家<br>
		·国家艺术基金人才培训项目、个人项目终审专家<br>
		·工业与信息部“优秀工业设计奖”终审专家<br>
		·“中国设计红星奖”终审专家 <br>
		·中国美术家协会工业设计艺术委员会副主任<br>
		·中国工业设计协会常务理事<br>
		·中国民间工艺专业委员会副主任委员<br>
		·北京设计学会会长<br>
		·北京工艺美术学会第四、第五届理事会副理事长<br>
		·北京工业设计协会副理事长<br>
		·中国民主同盟北京市委员会文化专业委员会主任（2013-2018）<br>
		·中央美术学院奥林匹克艺术研究中心副主任（2003-2008）<br>
		·第五、第七届中国工艺美术大师评审委员<br>
		·第九至十三届全国美展艺术设计展评审委员<br>
		·文化与旅游部第一、第二、第三届“中国设计大展”策展人、终评评审专家<br>
		·中国高等艺术教育研究院副院长<br>
		·中国艺术研究院研究生院博士生导师<br>
		·上海大学美术学院博士生导师<br>
		·山东工艺美术学院特聘院外专家顾问<br>
        </p>

      </div>
    </div>
</template>

<script>
    export default {
        name: "gaopeng"
    }
</script>

<style scoped>
  table{text-align: center;border-collapse: collapse;width: 100%;margin: 20px 0;}
  td{padding: 10px;border: #000 solid 1px;}
</style>
