<template>
    <div>
<!--      <h2 class="section-title">学习经历</h2>-->
      <div class="container-sm">
        <h2>王敏</h2>
        <strong>设计学科带头人</strong>
        <p>
          职称：教授 <br>
          研究领域：视觉传达设计
        </p>
        <strong>学习经历</strong>
        <p>
          1978.2-1982.2 中国美术学院 学士 <br>
          1986.9-1988.5 耶鲁大学艺术学院 硕士
        </p>
        <strong>代表著作</strong>
        <table>
          <tr>
            <td>序号</td><td>本人排序</td><td>年份</td><td>著作名称</td><td>出版单位</td>
          </tr>
          <tr>
            <td>1</td><td>1</td><td>2012</td><td>《凤与火》《玉与礼》《形与意》《云与气》丛书四本</td>
            <td>中国建筑工业出版社</td>
          </tr>
          <tr>
            <td>2</td><td>2</td><td>2017</td><td>《保罗•兰德给年轻人的第一堂课/伟大的设计师与卓越的教师》</td>
            <td>世界图书出版社</td>
          </tr>
          <tr>
            <td>3</td><td>1</td><td>2004</td><td>《两方世界　两方设计》</td><td>上海书画出版社</td>
          </tr>
        </table>

        <strong>代表论文</strong>
        <table>
          <tr>
            <td>序号</td><td>本人排序</td><td>年份</td><td>题目</td><td>期刊名称</td><td>卷期</td>
          </tr>
          <tr>
            <td>1</td><td>1</td><td>2019</td><td>用设计驱动中国创新发展、助力社会进步</td><td>人民日报</td><td>2019.9</td>
          </tr>
          <tr>
            <td>2</td><td></td><td>2019</td><td>Bringing algorithm and imagination together for powerful design</td>
            <td>Ico-D网</td><td>2019.11</td>
          </tr>
          <tr>
            <td>3</td><td>2</td><td>2016</td><td>关于设计驱动创新的探讨</td><td>装饰</td><td>2016.9</td>
          </tr>
        </table>
        <strong>主持的科研项目</strong>
        <table>
          <tr>
            <td>序号</td><td>起始时间</td><td>结束时间</td><td>项目名称</td><td>项目性质及来源</td><td>项目经费</td><td>本人排序</td>
          </tr>
          <tr>
            <td>1</td><td>2018.1</td><td>2018.12</td><td>北京设计周的主题展“改革开放后的中国设计” 策展人</td>
            <td>北京市政府</td><td>100万</td><td>1</td>
          </tr>
        </table>
        <strong>获奖情况</strong>
        <p>
          2009年获北京市有突出贡献科学、技术、管理人才奖 <br>
          2014年获光华龙腾奖设计贡献金质奖章<br>
          2019年获ico-D 国际设计组织联合会主席奖<br>
          2019年获光华龙腾特别奖：中国设计贡献金质奖章-新中国成立七十周年中国设计70人<br>
        </p>
        <strong>
          学术兼职
        </strong>
        <p>
          国际平面设计师协会（AGI）会员<br>
          北京奥运城市发展促进会会员<br>
          联合国教科文组织国际创意与可持续发展中心第一届咨询委员会委员<br>
          北京市西城区顾问团科技创新发展专委会成员<br>
          国务院学位办学位授权点调整评审工作专家<br>
          同济大学国际创新设计学院理事会理事<br>
          中国航天品牌形象总监<br>
          珠澳设计中心理事会主任<br>
        </p>



      </div>
    </div>
</template>

<script>
    export default {
        name: "gaopeng"
    }
</script>

<style scoped>
  table{text-align: center;border-collapse: collapse;width: 100%;margin: 20px 0;}
  td{padding: 10px;border: #000 solid 1px;}
</style>
