<template>
    <div>
<!--      <h2 class="section-title">学习经历</h2>-->
      <div class="container-sm">
        <h2>李琦</h2>
        <p>
        <strong>学术委员会委员（艺术与科技方向带头人）</strong><br>
          研究领域：数字地球、智慧城市系统与认知计算、大气污染与人体健康
        </p>
        <strong>专业及研究领域</strong>
        <table>
          <tr>
            <td>所属专业</td><td>遥感与地理信息系统</td>
          </tr>
          <tr>
            <td>研究领域</td><td>数字地球、智慧城市系统与认知计算、大气污染与人体健康</td>
          </tr>
          <tr>
            <td>
              本科生课程
            </td><td>
            遥感技术导论、城市与区域科学、数字地球导论
          </td>
          </tr>
          <tr>
            <td>研究生课程</td><td>智慧城市导论、智慧城市与健康中国前沿讨论班、数字地球与数字城市、中国的城市化（北京大学中欧留学生硕士班）</td>
          </tr>
        </table>
        <strong>教育经历</strong>
        <table>
          <tr>
            <td>时间</td><td>学位／证书</td><td>所在院校</td>
          </tr>
          <tr>
            <td>1975-1979</td><td>本科 / 学士</td><td>北京大学</td>
          </tr>
          <tr>
            <td>1978-1981</td><td>研究生 / 硕士</td><td>北京大学</td>
          </tr>
        </table>
        <strong>
          工作经历
        </strong>
        <table>
          <tr>
            <td>时间</td><td>职称／职务</td><td>所在单位</td>
          </tr>
          <tr>
            <td>1983-1987</td><td>讲师/副教授</td><td>北京大学遥感所</td>
          </tr>
          <tr>
            <td>1987-1989</td><td>客座科学家</td><td>西德斯图加特大学</td>
          </tr>
          <tr>
            <td>1990-1994</td><td>副教授</td><td>北京大学</td>
          </tr>
          <tr>
            <td>1994-1998</td><td>副所长</td><td>北京大学遥感与GIS所</td>
          </tr>
          <tr>
            <td>1994-至今</td><td>教授 / 博士生导师</td><td>北京大学遥感与GIS所</td>
          </tr>
        </table>
        <strong>承担项目</strong>
        <table>
          <tr>
            <td style="width: 30px;">序号</td><td>项目类别</td><td>承担角色</td><td>项目名称</td>
          </tr>
          <tr>
            <td>1</td><td>教育部</td><td>项目负责人</td><td>海外名师项目</td>
          </tr>
          <tr>
            <td>2</td><td>863</td><td>项目负责人</td><td>基于SIG框架的数字城市服务系统与示范（数字北京）</td>
          </tr>
          <tr>
            <td>3</td><td>973</td><td>课题负责人</td><td>网格环境下空间信息智能服务及应用示范</td>
          </tr>
          <tr>
            <td>4</td><td>自然科学基金</td><td>课题负责人</td><td>我国重要传染病流行病学数据的收集与整合及其共享分析技术平台研究</td>
          </tr>
          <tr>
            <td>5</td><td>科技支撑</td><td>课题负责人</td><td>基于多元空间环境探测的危险化学品事故全过程遥测预警和应急处置平台</td>
          </tr>
          <tr>
            <td>6</td><td>863</td><td>课题负责人</td><td>全球陆表特征参量产品集成生产系统研发与产品生成</td>
          </tr>
          <tr>
            <td>7</td><td>国家科技支撑计划</td><td>子课题负责人</td><td>气候变化与国家安全战略的关键技术研究</td>
          </tr>
          <tr>
            <td>8</td><td>横向课题</td><td>课题负责人</td><td>大连市普兰店区皮口特色小镇项目</td>
          </tr>
          <tr>
            <td>9</td><td>北京市经信委</td><td>课题负责人</td><td>北京智慧通州规划项目</td>
          </tr>
          <tr>
            <td>10</td><td>北京大学科技开发部</td><td>课题负责人</td><td>基于新一代信息技术的文化遗产保护与利用研究</td>
          </tr>
          <tr>
            <td>11</td><td>北京市科委</td><td>课题负责人</td><td>数字城市关键技术研究</td>
          </tr>
          <tr>
            <td>12</td><td>北京市科委</td><td>课题负责人</td><td>奥运通</td>
          </tr>
          <tr>
            <td>13</td><td>国家工信部</td><td>课题负责人</td><td>两化融合与工业碳排放定量分析与测算试点</td>
          </tr>
          <tr>
            <td>14</td><td>国家科技部</td><td>主要骨干</td><td>卫星遥感信息在山西农业自然资源定量分析应用研究</td>
          </tr>
          <tr>
            <td>15</td><td>国家发改委</td><td>课题负责人</td><td>国家空间基础设施关键技术研究</td>
          </tr>
          <tr>
            <td>16</td><td>国家科技部</td><td>子课题负责人</td><td>地球系统创新方法基础性设计与实施</td>
          </tr>
          <tr>
            <td>17</td><td>横向课题</td><td>课题负责人</td><td>智能城市与碳管理关键技术</td>
          </tr>
        </table>

          <p style="line-height: 24px;">
            <strong>学术成果</strong> <br>
            1.  Feng X, Li Q, Zhu Y, et al. An estimate of population exposure to automobile source PM 2.5 in Beijing using spatiotemporal analysis[C]//Geoscience and Remote Sensing Symposium (IGARSS), 2015 IEEE International. IEEE, 2015: 3029-3032.
            <br>2.  Liang H, Li Q. Hyperspectral imagery classification using sparse representations of convolutional neural network features[J]. Remote Sensing, 2016, 8(2): 99.
            <br>3.  Karimian H, Li Q, Li C, et al. An improved method for monitoring fine particulate matter mass concentrations via satellite remote sensing[J]. Aerosol and Air Quality Research, 2016, 16(4): 1081-1092.
            <br>4.  Xiao Feng, Qi Li, Yajie Zhu, Junxiong Hou, Lingyan Jin, Jingjie Wang “Artificial neural networks forecasting of PM2.5 pollution using air mass trajectory based geographic model and wavelet transformation”, Atmospheric Environment 107, 118-128, 2015.
            <br>5.  Xiao Feng, Qi Li, Yajie Zhu, Jingjie Wang, Heming Liang, Ruofeng Xu, “Formation and dominant factors of haze pollution over Beijing and its peripheral areas in winter”, Atmospheric Pollution Research, 2014, 528-538.
            <br>6.  Chi Zhang, Qi Li, “Application of Water Accounting Model to Tracking Moisture Sources of an Extreme Precipitation Event in Shandong, China in July 2007: A Computational Analysis”, Acta Meteorologica Sinica, 2014.
            <br>7.  Xiao Feng, Pengfeng Xiao, Qi Li, Xiaoxi Liu, Xiaocui Wu, “Hyperspectral image classification based on 3-D Gabor filter and support vector machines”, Spectroscopy and Spectral Analysis, 2013, 2218-2224.
            <br>8. Hamed Karimian, Qi Li, Huanfa Chen, “Accessing Urban Sustainable Development in Isfahan”, Applied Mechanics and Materials, 2013, 253-255, 244-248.
            <br>9. Danning Li, Qi Li, Xinqiang Ma, “Research of security mechanisms based on LogicSQL database”, Applied Mechanics and Materials, 2012, p352-356.
            <br>10. Chen Gong*, Li Qi, Liang Heming, Hamed Karimian, Mo Yuqin, Spatio-temporal simulation and analysis of regional ecological security based on lstm.ISSC.2017.
            <br>11. H.Karimian, Q.Li, C.C.Li, J.fan, C.Gong, L,Jin, Y.Mo. Daily Estimation of fine particulate matter mass concentration through satellite based aerosol optical depth. ISSC, 2017.
            <br>12. Junxiang Fan, Qi Li, Junxiong Hou, Yuqin Mo, Xiao Feng, Hamed Karimian and Shaofu Lin. A Spatiotemporal Prediction Framework for Air Pollution Based on Deep RNN. ISSC, 2017.
            <br>13. Xiao Feng, Qi Li, Yajie Zhu, “Bounding the role of domestic heating in haze pollution of Beijing based on satellite and surface observations”, International Geoscience and Remote Sensing Symposium (IGARSS), 2014.
            <br>14. Hamed Karimian, Qi Li, Huanfa Chen, “Correlation between AOD and PM2.5 over Tehran Iran”, Proceedings of International Conference on Earth Science and Environmental Protection (ICESEP), 2013.
            <br>15. Huanfa Chen, Qi Li, Yajie Zhu, Hamed Karimian, “Research of 3D simulation system for chemical accidents based on atmospheric dispersion model”, Proceedings of International Conference on Earth Science and Environmental Protection (ICESEP), 2013.
            <br>16. Yajie Zhu, Qi Li, Huanfa Chen, “System Design of a Simulation System for Hazardous Chemicals Leakage”, Proceedings of The 12th International Conference of GeoComputation, 2013.
         <br>   17. Jia, Siqi; Li, Qi; Liu, Shuai; Xue, Lei, A study on residential population estimation based on HJ-1 CCD image, Proceedings of the 2nd International Workshop on Earth Observation and Remote Sensing Applications, EORSA 2012, p287-290, 2012.
          <br>  18. Liu, Shuai; Li, Qi; Mao, Xi; Zhang, Junkui, Evaluation on consistency between HJ-1 CCD and TM images in monitoring fractional green vegetation cover, International Geoscience and Remote Sensing Symposium (IGARSS), p1005-1008, 2011.
        <br>    19. Liu, Shuai; Li, Qi, A study on green vegetation cover fraction based on HJ-1 CCD image, Proceedings–19th International Conference on Geoinformatics, Geoinformatics, 2011.
         <br>   20  Mao, Xi; Li, Qi, Ontology-based web spatial decision support system, Proceedings-19th International Conference on Geoinformatics, Geoinformatics, 2011.
        <br>    21. Zhang, Junkui; Zhao, Junyan; Jia, Siqi; Li, Qi; Liu, Shuai, A method to estimate the spatial distribution of transport carbon emissions in Shanghai Proceedings - 19th International Conference on Geoinformatics, Geoinformatics, 2011.
        <br>    22. Zhao, Junyan; Li, Qi; Zhou, Hongwei, A cloud-based system for spatial analysis service, 2011 International Conference on Remote Sensing, Environment and Transportation Engineering, RSETE 2011- Proceedings, p1-4, 2011.
       <br>     23. Zhao, Junyan; Zhang, Junkui; Jia, Siqi; Li, Qi; Zhu,Yue, A MapReduce framework for on-road mobile fossil fuel combustion CO2 emission, Proceedings - 19th International Conference on Geoinformatics, Geoinformatics, 2011.
        <br>    24. Liu, Shuai; Li, Qi; Zhou, Hongwei, An integrated spatio-temporal modeling and analysis framework for climate change research, 18th International Conference on Geoinformatics, Geoinformatics, 2010.
         <br>   25. Mao, Xi; Li, Qi; Zhang, Junkui, Distributed modeling environment for global climate change research, 18th International Conference on Geoinformatics, Geoinformatics, 2010.
         <br>   26. Xiong, Xingyu; Li, Qi; Zhang, Junkui, Study of spacializing social statistical data for carbon management, 18th International Conference on Geoinformatics, Geoinformatics, 2010.
          <br>  27. Yin, Qidong; Li, Qi; Wu, Xi, Research on spatial data interoperability in spatial data Grid environment, 3rd International Joint Conference on Computational Sciences and Optimization, CSO 2010: Theoretical Development and Engineering Practice, v2, p351-353, 2010.
         <br>   28. Yin, Qidong; Li, Qi, A method for modeling drivers' behavior rules in agent-based traffic simulation, 18th International Conference on Geoinformatics, Geoinformatics, 2010.
       <br>     29. Zhao, Junyan; Li, Qi, A method for modeling drivers' behavior rules in agent-based traffic simulation, 18th International Conference on Geoinformatics, Geoinformatics, 2010.
         <br>   30. 范竣翔, 李琦, 朱亚杰, 等. 基于 RNN 的空气污染时空预报模型研究[J]. 测绘科学, 2017, 42(7): 76-83.
           <br> 31. 陈工, 李琦, 金玲艳, 等. 基于深度学习的区域生态安全时空模拟与预测[J]. 地球信息科学学报, 2017, 19(7): 915-923.
       <br>     32. 陈工,李琦,陈劲松.多源遥感信息提取桉树人工林.林业科技 2017,7（08）：134-144.
        <br>    33. 侯俊雄, 李琦, 朱亚杰, 等. 基于随机森林的 PM2. 5 实时预报系统[J]. 测绘科学, 2017, 42(1): 1-6.
         <br>   34. 梁贺明, 李琦, 侯俊雄, 等. 北京市人口密度空间分布及其尺度特性研究[J]. 地理信息世界, 2016, 23(6): 31-38.
         <br>   35. 袁泽, 李琦. 基于 LCA 的工业过程碳排放建模和环境评价[J]. 测绘科学, 2017, 42(5): 196-200.
         <br>   36. 王晶杰, 李琦, 冯逍, 朱亚杰. 京津冀地区污染过程的气溶胶遥感反演[J]. 测绘科学, 2015(2), 78-83.
          <br>  37. 王晶杰, 李琦. 基于SARA 算法的京津冀地区气溶胶遥感反演[J]. 地球科学期刊, 2015, 5(3).
          <br>  38. 李琦，陈焕发，金玲艳，面向智慧城市碳管理的碳计量模型[J]，测绘科学，2014(8)，16-23.
          <br>  39. 朱亚杰, 李琦，冯逍, 基于大数据的智慧城市技术体系架构研究[J]. 测绘科学，2014(8), 70-73.
          <br>  40. 金玲艳，李琦，基于智慧城市的雾霾求解系统探索[J]，测绘科学，2014(8)，78-82.
            <br>41. 陈焕发，李琦，侯俊雄，朱亚杰，基于OpenSceneGraph的危化品泄漏事故二三维一体化仿真研究[J]，计算机应用研究增刊, 2014.
           <br> 42. 薛磊，李琦，刘帅，北京城市产业碳排放的小尺度空间分布[J]，地理研究，2013(7), 1188-1198.
           <br> 43. 李琦，查传捷，面向气候变化地球系统模拟建模探索(上)[J]，自然杂志，2012(3), 125-138.
           <br> 44. 查传捷，李琦，面向气候变化地球系统模拟建模探索(下)[J]，自然杂志，2012(6), 318-326.
           <br> 45. 毛曦，李琦，张子民，基于Web Service 的地球系统碳循环建模框架研究[J], 地理信息世界，2012(2), 57-64.
           <br> 46. 毛曦，李琦，刘帅，朱亚杰，面向网络的空间信息提取系统研究[J]，计算机科学，2012(6A), 229-232.
           <br> 47. 朱钥，李琦，城市空间智能计算平台研究[J]，地理与地理信息科学，2011(1), 11-20.
           <br> 48. 朱钥，李琦，余铁桥，基于复杂系统理论的应急模拟演练平台研究[J]，计算机应用研究，2011(1), 195-202.
           <br> 49. 朱钥，贾思奇，张俊魁，李琦，基于Hadoop的城市交通碳排放数据挖掘研究[J]，计算机应用研究，2011(11), 4213-4215.
           <br> 50. 张子民，周英，李琦，毛曦，图形化的地学耦合建模环境与原型系统设计[J]，地球信息科学学报，2011(1), 48-57.
           <br> 51. 周红伟，李琦，基于云计算的空间信息服务系统研究[J], 计算机应用研究，2011(7), 2586-2588.
           <br> 52. 毛曦，李琦，基于本体的网络空间决策支持系统研究[J]，计算机应用研究，2010(10), 3810-3812.
           <br> 53. 廖通逵，李琦，殷崎栋，张燕，基于服务总线的空间信息服务集成技术研究[J]，GIS技术，2010(4), 105-111.
           <br> 54. 廖通逵，李琦，张燕，殷崎栋，基于ESB 的数字城市信息资源共享服务平台研究与实现[J]，GIS技术，2010(6), 106-109.
           <br> 55. 张子民，李琦，朱强，基于组件的空间集成建模研究[J]，计算机应用研究，2010(1), 124-130.
           <br> 56. 张子民，周英，李琦，林俞先，城市局域动态人口估算方法与模拟应用[J]，地球信息科学学报，2010(4), 503-509.
           <br> 57. 张子民，周英，李琦，毛曦，突发有毒气体泄漏事故应急模型开发[J]，中国安全科学学报, 2010(7), 151-157
           <br> 58. 张子民，周英，李琦，毛曦，基于信息共享的突发事件应急响应信息模型(I): 模型定义[J]，中国安全科学学报，2010(8), 154-160.
            <br>59. 张子民，周英，李琦，毛曦，基于信息共享的突发事件应急响应信息模型(II):模型计算[J]，中国安全科学学报，2010(9), 158-165.

          </p>
          <p>
            <strong>获奖情况</strong>
          </p>
          <table>
            <tr>
              <td>序号</td><td>获奖项目或成果名称</td>
              <td>奖励名称</td><td>奖励等级</td><td>本人排序</td><td>获奖年度</td><td>授予机构</td>
            </tr>
            <tr>
              <td>1</td><td>泰坦V6.0机器智能空间信息处理技术</td><td>北京市科学技术将</td>
              <td>二等</td><td>2</td><td>2006</td><td>北京市人民政府</td>
            </tr>
            <tr>
              <td>2</td><td>空间信息基础设施关键技术研究</td><td>中国高校科学技术奖</td>
              <td>二等</td><td>3</td><td>2001</td><td>国家教育部</td>
            </tr>
            <tr>
              <td>3</td><td>黄土高原小流域水土保持环境影响评估研究</td><td>国家教育委员会科学进步奖</td>
              <td>二等</td><td>4</td><td>1995</td><td>国家教育委员会</td>
            </tr>
            <tr>
              <td>4</td><td>国家数据库管理系系统PRIDBMS及地理信息系统System-W</td><td>北京大学第三届科学技术研究成果</td>
              <td>二等</td><td>6</td><td>1991</td><td>北京大学</td>
            </tr>
            <tr>
              <td>5</td><td>卫星遥感信息在山西农业自然资源中的应用研究</td><td>北京大学科学研究成果奖</td>
              <td>一等</td><td>3</td><td>1986</td><td>北京大学</td>
            </tr>
            <tr>
              <td>6</td><td>卫星遥感信息在山西农业自然资源中的应用研究</td><td>国家科技攻关成果奖</td>
              <td>特等</td><td>3</td><td>1985</td><td>国家规划委、经委、教委、国务院电子振兴办、国务院重大科学技术装备办</td>
            </tr>
          </table>
          <strong>学术及社会任职</strong>
          <p>
            <br> 2017—至今：健康中国科技创新与产融服务平台项目首席科学家；
            <br>2016—至今：北京市高精尖未来网络中心智慧城市与时空大数据团队负责人；
            <br>2016—至今：北京市十三五信息化发展规划专家组专家；
            <br>2015—至今：国家教育部信息网络工程研究中心博士生导师；
            <br>2013—至今：中国信息协会资源环境专业委员会副主任；
            <br>2013—至今：中国电子商务创新推进联盟专家组专家；
            <br>2009—至今：工信部信息化推进司两化融合专家组专家；
            <br>2008—至今：北京大学智慧城市研究中心主任；
            <br>2004—至今：北京大学数字中国研究院学术委员会副主任；
            <br>2001—至今：北京市空间信息集成与 3S 工程应用重点实验室学术委员会副主席；
           <br> 2001—至今：民盟中央科技委员；
           <br> 北京市，重庆市，柳州，秦皇岛，荣成科技顾问；
           <br> 澳门科技大学，云南大学，昆明师范大学，山东农业大学，大连海事大学兼职教授；
           <br> 1994—2005：中国图形图像学会副秘书长，技术委员主任。

          </p>


        </table>

      </div>
    </div>
</template>

<script>
    export default {
        name: "gaopeng"
    }
</script>

<style scoped>
  table{text-align: center;border-collapse: collapse;width: 100%;margin: 20px 0;}
  td{padding: 10px;border: #000 solid 1px;}
</style>
