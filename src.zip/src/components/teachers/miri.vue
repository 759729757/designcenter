<template>
    <div>
<!--      <h2 class="section-title">学习经历</h2>-->
      <div class="container-sm">
        <h2>Miriam Mirolla</h2>
        <p><strong>学术委员会委员（未来理论、艺术心理方向带头人）</strong><br>
          研究领域：艺术史论、当代艺术、交互理论和应用技术<br>
          个人主页：www.miriammirolla.it
        </p>
        <p>
          Miriam Mirolla， 1967年4月25日生，常居罗马，主要研究方向包括当代艺术、教育、先锋派理论、慈善事业、艺术心理学、数字人文、阈下知觉、性别研究和神话学。至今发表过多篇期刊论文、会议论文及学术著作，承办过多场团体和个人展览。现阶段研究重点为实验性教学和科研、互动理论、艺术馆和艺术教育的技术应用。
          <br><br>最近出版物为《The art that enlightens the future》（中文和意大利语），并在筹备新书《 Contemporary art, from 1945 until today》。
         <br> <br>自20世纪80年代末期，Miriam Mirolla开始在罗马接受大学教育，学习原始主义和先锋派理论的开放性辩证，并开始研究未来艺术概念。1986年，她在罗马亚特拉克艺术心理学实验研究中心研究由艺术家和心理学家Sergio Lombardo创立的终极主义理论。随后，她成为Journal of Art Psychology期刊科学委员会委员。Miriam Mirolla于1991年获得罗马大学文学与哲学学士学位，随后在P.S.1纽约当代艺术中心担任实习策展人，积累了丰富的策展和互动教育经验。
         <br> <br>1995年起，Miriam Mirolla开始在意大利多个高等院校从事艺术教育工作，包括都灵美术学院（Academy of Fine Arts in Turin）、意大利佩鲁贾大学教育科学学院(University of Human Sciences and Education in Perugia)、Quasar设计学院（Quasar Institute for Advanced Design）和罗马美术学院（Academy of Fine Arts in Rome），并在罗马美术学院担任知觉理论和艺术心理学主任教授。
        <br> <br> Miriam Mirolla拥有丰厚的艺术教育教学和研究经验，作为学术教授和实验艺术家，她拥有坚实的理论基础，并带领学生与罗马市主要机构开展系统的开拓性合作，包括卡比托利欧博物馆、罗马市政府、Camillo and Marguerite Caetani基金会、MAXXI基金会、MACRO博物馆和礼堂博物馆。她是罗马卡比托利欧博物馆第一届艺术心理学委员会的发起人和主席、艺术心理学实验室（LAP）的创始人和科学总监、艺术心理学经验协会创始人和主席、罗马当代艺术博物馆第二届艺术心理学委员会主任。
        <br>  <br>作为实验艺术家，Miriam Mirolla策划了多场展览和实验，成果主要集中在《Miriam Mirolla, Experiments in Art》（2017年发表于Melchiorre E.）一书中。数十年来，Miriam Mirolla一直在美国、英国、德国、俄罗斯和中国推动意大利艺术和先锋派理论的研究，包括伦敦艺术大学（1994年）、温布顿艺术学院（1998年）、莫斯科艺术研究学院（2011年）、北京意大利文化馆（2017年）、德国伍珀塔尔大学（2017年）、佛罗里达大西洋大学计算机电气工程与计算机科学系（2017年）和罗马大学（2018年）。
        <br>  <br>在中国，自2015年起，Miriam Mirolla开始推广艺术心理学实验讲授法，并成功举办以下活动：
        <br> <br> -	2015年，青岛市艺术心理学实验室（LAP）“Elements of Art Psychology”；
        <br>  <br>-	2015年，北京市798艺术区“The Self-Cube and other experiments of Art Psychology”（个人展）；
        <br>  <br>-	2016年，青岛市美术馆“Avant-Garde Self-Portrait”（实验展）；
        <br>  <br>-	2016年，青岛市艺术心理学实验室（LAP）“Art, personality and fantasy”；
        <br>  <br>-	2017年，青岛市艺术心理学实验室（LAP）“From Futurism to Eventualism”；
        <br> <br> -	2017年，意大利大使馆、意大利使馆文化处“The art that enlightens the future. Theories and works of the Italian Avant-garde, from Futurism to Eventualism”；
        <br> <br> -	2018年，北京朱乃正艺术研究中心 “Art, Non-Art and Anti-Art. Revisit Marcel Duchamp”；
        <br> <br> -	2018年，青岛市艺术心理学实验室（LAP）“Renaissance, Futurism, Eventualism”；
        <br> <br> -	2019年，青岛市艺术心理学实验室（LAP）“The Chinese dream”；
        <br> <br> -	2019年，北京市今日美术馆“Dragonfly Eyes by Xu Bing. Some theoretical considerations”。
        <br>  <br>
       <br>  <br> 作为当代艺术评论家和记者，Miriam Mirolla曾与多位知名艺术家共同发表多篇期刊文章和采访，包括国际知名艺术家Sergio Lombardo、Fabio Mauri、Maurizio Mochetti、Joseph Kosuth、Peter Halley、Xu Bing，收藏家和慈善家Dakis Joannou （雅典Deste 基金会）, Martin Margulies （迈阿密Margulies Warehouse美术馆）, Jorge Perez （迈阿密PAMM美术馆, Miami）, Emi Fontana （洛杉矶）, Rubell Family Foundation（迈阿密）, Norman Braman （洛杉矶当代艺术学院博物馆）, George Wong（北京芳草地）。

        </p>

      </div>
    </div>
</template>

<script>
    export default {
        name: "gaopeng"
    }
</script>

<style scoped>
  table{text-align: center;border-collapse: collapse;width: 100%;margin: 20px 0;}
  td{padding: 10px;border: #000 solid 1px;}
</style>
