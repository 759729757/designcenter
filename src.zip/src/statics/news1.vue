<template>
  <div>
    <h2 class="rich_media_title" id="activity-name">
      未来设计中心FDC主任高鹏浅谈艺术教育
    </h2>
    <div class="rich_media_content " id="js_content" style="visibility: visible;">

      <section
        style="margin-right: 16px;margin-bottom: 40px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;min-height: 1em;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;">
        <br><p>
        <small style="font-size: 12px;">内容转载自“雅昌艺术网”2020年9月9日新闻 <br>
        原标题  对话高鹏：从美术馆到学院 做艺术教育的摆渡人</small></p>

      </section>

      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <strong><span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;">最新消息称，原今日美术馆馆长高鹏已正式加入北京师范大学，将在北师大珠海校区筹建一所关于未来概念的设计学院。</span></strong><span
        style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"></span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"><br></span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;">这位曾享有“中国最年轻美术馆馆长”之誉的美术馆人，总是让人感到“意外”。从今年3月份卸任馆长至今，<strong>高鹏从“高馆长”华丽转身成为“高老师”，将致力于艺术教育，成为人师，做艺术教育的摆渡人。这是9月10日教师节来临之际关于艺术教育的好消息，祝高老师教师节快乐！</strong></span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"><br></span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <img data-backh="401" data-backw="600" data-ratio="0.6675"
             data-src="https://mmbiz.qpic.cn/mmbiz_jpg/xIYMgH7g8Q5fSXTMvwiaJyeJibsjAz1DAXpEhD0avSVbAmPPoyaFJbC3icqiawBTyLScvl1ZoduIk4TuZp2DVK5WHg/640?wx_fmt=jpeg"
             data-type="jpeg" data-w="2000"
             style="max-width: 600px; width: 100% !important; height: auto !important; visibility: visible !important;"
             title="" _width="100%" class=""
             src="./imgs/gaopeng.webp.jpg"
             crossorigin="anonymous" data-fail="0"></p>
      <p
        style="text-align: center;margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;font-family: Optima-Regular, PingFangTC-light;letter-spacing: 1.5px;color: rgb(123, 127, 131);font-size: 12px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;">高鹏</span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <br></p>
      <section powered-by="xiumi.us"
               style="max-width: 100%;box-sizing: border-box;white-space: normal;background-color: rgb(255, 255, 255);font-size: 48px;letter-spacing: 2px;font-family: PingFangSC-light;color: rgba(217, 214, 214, 0.33);word-wrap: break-word !important;">
        <p
          style="max-width: 100%;box-sizing: border-box;min-height: 1em;text-align: center;word-wrap: break-word !important;">
          <strong style="max-width: 100%;box-sizing: border-box;word-wrap: break-word !important;"><em
            style="max-width: 100%;box-sizing: border-box;word-wrap: break-word !important;">01</em></strong></p>
      </section>
      <section powered-by="xiumi.us"
               style="margin-top: -35px;max-width: 100%;box-sizing: border-box;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;font-size: 16px;background-color: rgb(255, 255, 255);word-wrap: break-word !important;">
        <section
          style="max-width: 100%;box-sizing: border-box;letter-spacing: 2px;text-shadow: rgb(221, 219, 219) 1px 2px;color: rgb(122, 120, 120);font-family: Optima-Regular, PingFangTC-light;word-wrap: break-word !important;">
          <p
            style="max-width: 100%;box-sizing: border-box;min-height: 1em;text-align: center;word-wrap: break-word !important;">
            <span
              style="max-width: 100%;font-size: 18px;box-sizing: border-box !important;word-wrap: break-word !important;"><strong
              style="max-width: 100%;box-sizing: border-box;word-wrap: break-word !important;">深耕十年 选择离开</strong></span>
          </p></section>
      </section>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"><br></span><br>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"></span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;">高鹏进入艺术界的视野，更多的是从“作为80后馆长上任今日美术馆馆长”带来的关注和热议开始的。</span><br>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"><br></span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;">回想2013年，高鹏上任今日美术馆馆长，当时人们还很难想象，一个中国重要美术馆的馆长是30岁出头的年轻人，也不知道当时仍年轻的80后会给困难重重的民营美术馆行业带来多大改变。</span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"><br></span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <img data-backh="276" data-backw="546" data-ratio="0.506"
             data-src="https://mmbiz.qpic.cn/mmbiz_jpg/xIYMgH7g8Q5fSXTMvwiaJyeJibsjAz1DAXdKZ1zQbMMXXa9AUOhU5TaTY90FRZPO8bs7iaPP0l8kPsxRVHqicVLvgA/640?wx_fmt=jpeg"
             data-type="jpeg" data-w="2000"
             style="width: 100% !important; height: auto !important; visibility: visible !important;"
             title="2.2015年 第一届今日未来馆“想象的未来”" _width="100%" class=""
             src="./imgs/2.webp.jpg"
             crossorigin="anonymous" data-fail="0"></p>
      <p
        style="text-align: center;margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;font-family: Optima-Regular, PingFangTC-light;letter-spacing: 1.5px;color: rgb(123, 127, 131);font-size: 12px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;">2015年 第一届今日未来馆“想象的未来”</span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <br></p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;">七年来，高鹏带领着一个年轻的美术馆团队，逐渐为国内的民营美术馆探索出一条“造血”之路。在高鹏执掌下，今日美术馆继续打造“今日文献展”等原有学术品牌，并快速推进有着“造血功能”的基金会和理事会制度，更先后成立“新媒体实验室”、“今日艺术学院”，成功推出了“今日未来馆”这样具有探索精神，引领未来趋势判断的品牌项目。2019年，今日美术馆也正式入选北京大学MBA案例中心，该案例已经应用在光华管理学院MBA的课程教学。</span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"><br></span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;">当中国民营美术馆的发展逐渐迅猛，大众对美术馆的认识提升到一个新的层面，所有人都认为今日美术馆在高鹏的带领下，应该继续大展未来蓝图的时候，高鹏发布消息离任今日美术馆馆长，在美术馆行业耕耘十年后，他选择离开。</span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"><br></span>
      </p>
      <section powered-by="xiumi.us"
               style="max-width: 100%;box-sizing: border-box;white-space: normal;background-color: rgb(255, 255, 255);font-size: 48px;letter-spacing: 2px;font-family: PingFangSC-light;color: rgba(217, 214, 214, 0.33);word-wrap: break-word !important;">
        <p
          style="max-width: 100%;box-sizing: border-box;min-height: 1em;text-align: center;word-wrap: break-word !important;">
          <strong style="max-width: 100%;box-sizing: border-box;word-wrap: break-word !important;"><em
            style="max-width: 100%;box-sizing: border-box;word-wrap: break-word !important;">02</em></strong></p>
      </section>
      <section powered-by="xiumi.us"
               style="margin-top: -35px;max-width: 100%;box-sizing: border-box;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;font-size: 16px;background-color: rgb(255, 255, 255);word-wrap: break-word !important;">
        <section
          style="max-width: 100%;box-sizing: border-box;letter-spacing: 2px;text-shadow: rgb(221, 219, 219) 1px 2px;color: rgb(122, 120, 120);font-family: Optima-Regular, PingFangTC-light;word-wrap: break-word !important;">
          <p
            style="max-width: 100%;box-sizing: border-box;min-height: 1em;text-align: center;word-wrap: break-word !important;">
            <span
              style="max-width: 100%;font-size: 18px;box-sizing: border-box !important;word-wrap: break-word !important;"><strong
              style="max-width: 100%;box-sizing: border-box;word-wrap: break-word !important;">学为人师 行为世范</strong></span>
          </p></section>
      </section>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"><br></span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <br></p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <strong><span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;">关于高鹏为何选择离开今日美术馆？为何加入北京师范大学？什么是“未来概念设计学院”？关于高鹏未来的工作将会有哪些新的方向，我们带着大家关注的系列疑问，</span></strong><strong><span
        style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;">邀请高鹏深度对话：</span></strong><span
        style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"><br></span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"><br></span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <img data-backh="400" data-backw="600" data-ratio="0.6665"
             data-src="https://mmbiz.qpic.cn/mmbiz_jpg/xIYMgH7g8Q5fSXTMvwiaJyeJibsjAz1DAXsiahiacib3k9ujZVCjE2qHKVuUwAD9TMZMRcuzBtoXwjy37JxRjhfrlaQ/640?wx_fmt=jpeg"
             data-type="jpeg" data-w="2000"
             style="max-width: 600px; width: 100% !important; height: auto !important; visibility: visible !important;"
             title="2.2015年 第一届今日未来馆“想象的未来”" _width="100%" class=""
             src="./imgs/3.webp.jpg"
             crossorigin="anonymous" data-fail="0"></p>
      <p
        style="text-align: center;margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;font-family: Optima-Regular, PingFangTC-light;letter-spacing: 1.5px;color: rgb(123, 127, 131);font-size: 12px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;">2018年，今日美术馆受邀在罗马国家现当代美术馆巡展</span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"></span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <br></p>
      <section
        style="font-size: 15px;font-family: PingFangSC-light;padding-right: 8px;padding-left: 8px;box-sizing: border-box;">
        <section style="box-sizing: border-box;" powered-by="xiumi.us">
          <section style="display: flex;flex-flow: row nowrap;box-sizing: border-box;">
            <section
              style="display: inline-block;vertical-align: middle;width: auto;flex: 0 0 0%;align-self: center;height: auto;padding-right: 10px;padding-left: 10px;box-sizing: border-box;">
              <section
                style="transform: rotateZ(45deg);-webkit-transform: rotateZ(45deg);-moz-transform: rotateZ(45deg);-o-transform: rotateZ(45deg);box-sizing: border-box;"
                powered-by="xiumi.us">
                <section
                  style="text-align: center;font-size: 0px;margin-right: 0%;margin-left: 0%;box-sizing: border-box;">
                  <section
                    style="display: inline-block;width: 8px;height: 8px;vertical-align: top;overflow: hidden;border-style: solid;border-width: 2px;border-radius: 0px;border-color: rgb(230, 179, 34);box-shadow: rgba(255, 255, 255, 0) 2px -2px 0px;background-color: rgba(230, 179, 34, 0.07);box-sizing: border-box;line-height: 0;">
                    <br></section>
                </section>
              </section>
            </section>
            <section
              style="display: inline-block;vertical-align: middle;width: auto;align-self: center;flex: 100 100 0%;box-sizing: border-box;">
              <section style="text-align: left;color: rgb(206, 167, 20);letter-spacing: 1px;box-sizing: border-box;"
                       powered-by="xiumi.us"><p style="box-sizing: border-box;"><strong><span
                style="color: rgb(230, 179, 34);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">艺术头条：为什么离开今日美术馆？</span></strong><span
                style="color: rgb(230, 179, 34);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);"></span>
              </p></section>
            </section>
          </section>
        </section>
        <section
          style="display: inline-block;width: 100%;vertical-align: top;border-width: 0px;padding-left: 14px;letter-spacing: 0px;box-sizing: border-box;"
          powered-by="xiumi.us">
          <section
            style="display: inline-block;width: 100%;vertical-align: top;border-left: 1px solid rgb(230, 179, 34);border-bottom-left-radius: 0px;padding-top: 6px;padding-bottom: 20px;padding-left: 13px;letter-spacing: 0px;box-sizing: border-box;"
            powered-by="xiumi.us">
            <section
              style="font-size: 14px;color: rgb(84, 75, 110);letter-spacing: 1.8px;line-height: 1.8;box-sizing: border-box;"
              powered-by="xiumi.us"><p style="white-space: normal;box-sizing: border-box;"><br></p>
              <p style="white-space: normal;box-sizing: border-box;"><strong><span
                style="font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);color: rgb(230, 179, 34);">高鹏：</span></strong><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">我一直感觉自己是幸运的，今年是我加入今日美术馆的第十年，想停一停。特别是做馆长以来，做的一些事情得到了很多的鼓励和关注，同时大家也会对你有更高的期望。但有时候也会很无力，美术馆的工作往往是呈现一个艺术思考的结果，当遇到一些并不认同的审美及文化价值作品的时候，作为馆长心里是很矛盾的，特别是当代艺术更加复杂，需要考虑的因素更多。</span>
              </p></section>
          </section>
        </section>
        <section style="box-sizing: border-box;" powered-by="xiumi.us">
          <section style="display: flex;flex-flow: row nowrap;box-sizing: border-box;">
            <section
              style="display: inline-block;vertical-align: middle;width: auto;flex: 0 0 0%;align-self: center;height: auto;padding-right: 10px;padding-left: 10px;box-sizing: border-box;">
              <section
                style="transform: rotateZ(45deg);-webkit-transform: rotateZ(45deg);-moz-transform: rotateZ(45deg);-o-transform: rotateZ(45deg);box-sizing: border-box;"
                powered-by="xiumi.us">
                <section
                  style="text-align: center;font-size: 0px;margin-right: 0%;margin-left: 0%;box-sizing: border-box;">
                  <section
                    style="display: inline-block;width: 8px;height: 8px;vertical-align: top;overflow: hidden;border-style: solid;border-width: 2px;border-radius: 0px;border-color: rgb(230, 179, 34);box-shadow: rgba(255, 255, 255, 0) 2px -2px 0px;background-color: rgba(230, 179, 34, 0.07);box-sizing: border-box;line-height: 0;">
                    <br></section>
                </section>
              </section>
            </section>
            <section
              style="display: inline-block;vertical-align: middle;width: auto;align-self: center;flex: 100 100 0%;box-sizing: border-box;">
              <section style="text-align: left;color: rgb(206, 167, 20);letter-spacing: 1px;box-sizing: border-box;"
                       powered-by="xiumi.us"><p style="box-sizing: border-box;"><span style="color: rgb(230, 179, 34);"><strong><span
                style="color: rgb(230, 179, 34);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">艺术头条：为什么是北京师范大学呢？</span></strong></span>
              </p></section>
            </section>
          </section>
        </section>
        <section
          style="display: inline-block;width: 100%;vertical-align: top;border-width: 0px;padding-left: 14px;letter-spacing: 0px;box-sizing: border-box;"
          powered-by="xiumi.us">
          <section
            style="display: inline-block;width: 100%;vertical-align: top;border-left: 1px solid rgb(230, 179, 34);border-bottom-left-radius: 0px;padding-top: 6px;padding-bottom: 20px;padding-left: 13px;letter-spacing: 0px;box-sizing: border-box;"
            powered-by="xiumi.us">
            <section
              style="font-size: 14px;color: rgb(84, 75, 110);letter-spacing: 1.8px;line-height: 1.8;box-sizing: border-box;"
              powered-by="xiumi.us"><p style="white-space: normal;box-sizing: border-box;"><br></p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(230, 179, 34);"><strong><span
                style="font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">高鹏：</span></strong></span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">选择来到北京师范大学既可以说是瞬间的决定，也是长期思考的结果。十年对我而言有特殊的意义，时常会思考工作的意义是什么？我已经不再是30岁的时候，站在当下思考的是未来十年值得付出的事业。</span><br>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);"><br></span>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">艺术设计教育是一个必然导出来的思维方向，觉得这件事值得做。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">基础教育是之后我最想做的工作，去真正实现自己的教育理想，为教育做一点真真正正的事。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">北师大是种子教育，是培养未来青年教师的地方，是基础教育的地方，我觉得没有什么理由拒绝这份邀请。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">这是自己想从美术馆领域进入到基础艺术教育领域的一个最根本原因。</span>
              </p></section>
          </section>
        </section>
        <section style="box-sizing: border-box;" powered-by="xiumi.us">
          <section style="display: flex;flex-flow: row nowrap;box-sizing: border-box;">
            <section
              style="display: inline-block;vertical-align: middle;width: auto;flex: 0 0 0%;align-self: center;height: auto;padding-right: 10px;padding-left: 10px;box-sizing: border-box;">
              <section
                style="transform: rotateZ(45deg);-webkit-transform: rotateZ(45deg);-moz-transform: rotateZ(45deg);-o-transform: rotateZ(45deg);box-sizing: border-box;"
                powered-by="xiumi.us">
                <section
                  style="text-align: center;font-size: 0px;margin-right: 0%;margin-left: 0%;box-sizing: border-box;">
                  <section
                    style="display: inline-block;width: 8px;height: 8px;vertical-align: top;overflow: hidden;border-style: solid;border-width: 2px;border-radius: 0px;border-color: rgb(230, 179, 34);box-shadow: rgba(255, 255, 255, 0) 2px -2px 0px;background-color: rgba(230, 179, 34, 0.07);box-sizing: border-box;line-height: 0;">
                    <br></section>
                </section>
              </section>
            </section>
            <section
              style="display: inline-block;vertical-align: middle;width: auto;align-self: center;flex: 100 100 0%;box-sizing: border-box;">
              <section style="text-align: left;color: rgb(206, 167, 20);letter-spacing: 1px;box-sizing: border-box;"
                       powered-by="xiumi.us"><p style="box-sizing: border-box;"><strong><span
                style="color: rgb(230, 179, 34);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">艺术头条：从美术馆进入北京师范大学，这所学校吸引你的地方在哪里？</span></strong>
              </p></section>
            </section>
          </section>
        </section>
        <section
          style="display: inline-block;width: 100%;vertical-align: top;border-width: 0px;padding-left: 14px;letter-spacing: 0px;box-sizing: border-box;"
          powered-by="xiumi.us">
          <section
            style="display: inline-block;width: 100%;vertical-align: top;border-left: 1px solid rgb(230, 179, 34);border-bottom-left-radius: 0px;padding-top: 6px;padding-bottom: 20px;padding-left: 13px;letter-spacing: 0px;box-sizing: border-box;"
            powered-by="xiumi.us">
            <section
              style="font-size: 14px;color: rgb(84, 75, 110);letter-spacing: 1.8px;line-height: 1.8;box-sizing: border-box;"
              powered-by="xiumi.us"><p style="white-space: normal;box-sizing: border-box;"><br></p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(230, 179, 34);"><strong><span
                style="font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">高鹏：</span></strong></span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">北师大的校训特别感染我，“学为人师，行为世范”这是一个多么高的理想和准则。</span>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);"><br></span>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">北师大既有全面的通识教育，也有心理学和教育学等专业优势学科，可以依托北师大的综合性优势，不断优化现在的艺术基础教育。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">据了解，北师大是全国45%的教材编撰地，我希望有机会也能够参与艺术教材与读物的编撰工作，尽最大可能做出自己的贡献。</span>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);"><br></span>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">伴随着新技术出现，世界走向一种新的生活方式，是一种多元的，电子化的，新语言、新交流模式和体验感的这样一个未来。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">人的成长就是终身学习，不断进行自我迭代。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">如同信息技术会升级，人只有不断打破已有经验，以未来社会人类生活模式和需求为根本，可持续地创新，才能面向更好的未来。</span>
              </p></section>
          </section>
        </section>
      </section>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <br><span
        style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"></span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"></span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <img data-ratio="0.6665"
             data-src="https://mmbiz.qpic.cn/mmbiz_jpg/xIYMgH7g8Q5fSXTMvwiaJyeJibsjAz1DAXG2Xmul9R9syPB7icd4T5R7SQiavxaIicmCMNXAXblIIia04gQLUPBO2QMQ/640?wx_fmt=jpeg"
             data-type="jpeg" data-w="2000"
             style="max-width: 600px; width: 100% !important; height: auto !important; visibility: visible !important;"
             title="4.2019年 第三届今日未来馆“机器人间”" data-backw="600" data-backh="400" _width="100%" class=""
             src="./imgs/4.webp.jpg"
             crossorigin="anonymous" data-fail="0"></p>
      <p
        style="text-align: center;margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;font-family: Optima-Regular, PingFangTC-light;letter-spacing: 1.5px;color: rgb(123, 127, 131);font-size: 12px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;">2019年 第三届今日未来馆“机器人间”</span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;font-family: Optima-Regular, PingFangTC-light;letter-spacing: 1.5px;color: rgb(123, 127, 131);font-size: 12px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"><br></span>
      </p>
      <section
        style="font-size: 15px;font-family: PingFangSC-light;padding-right: 8px;padding-left: 8px;box-sizing: border-box;">
        <section style="box-sizing: border-box;" powered-by="xiumi.us">
          <section style="display: flex;flex-flow: row nowrap;box-sizing: border-box;">
            <section
              style="display: inline-block;vertical-align: middle;width: auto;flex: 0 0 0%;align-self: center;height: auto;padding-right: 10px;padding-left: 10px;box-sizing: border-box;">
              <section
                style="transform: rotateZ(45deg);-webkit-transform: rotateZ(45deg);-moz-transform: rotateZ(45deg);-o-transform: rotateZ(45deg);box-sizing: border-box;"
                powered-by="xiumi.us">
                <section
                  style="text-align: center;font-size: 0px;margin-right: 0%;margin-left: 0%;box-sizing: border-box;">
                  <section
                    style="display: inline-block;width: 8px;height: 8px;vertical-align: top;overflow: hidden;border-style: solid;border-width: 2px;border-radius: 0px;border-color: rgb(230, 179, 34);box-shadow: rgba(255, 255, 255, 0) 2px -2px 0px;background-color: rgba(230, 179, 34, 0.07);box-sizing: border-box;line-height: 0;">
                    <br></section>
                </section>
              </section>
            </section>
            <section
              style="display: inline-block;vertical-align: middle;width: auto;align-self: center;flex: 100 100 0%;box-sizing: border-box;">
              <section style="text-align: left;color: rgb(206, 167, 20);letter-spacing: 1px;box-sizing: border-box;"
                       powered-by="xiumi.us"><p style="box-sizing: border-box;"><strong><span
                style="color: rgb(230, 179, 34);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">艺术头条：诚然，教育美术馆和学院的重要职能之一，在进入学院之时，你对艺术教育有怎样的思考？</span></strong>
              </p></section>
            </section>
          </section>
        </section>
        <section
          style="display: inline-block;width: 100%;vertical-align: top;border-width: 0px;padding-left: 14px;letter-spacing: 0px;box-sizing: border-box;"
          powered-by="xiumi.us">
          <section
            style="display: inline-block;width: 100%;vertical-align: top;border-left: 1px solid rgb(230, 179, 34);border-bottom-left-radius: 0px;padding-top: 6px;padding-bottom: 20px;padding-left: 13px;letter-spacing: 0px;box-sizing: border-box;"
            powered-by="xiumi.us">
            <section
              style="font-size: 14px;color: rgb(84, 75, 110);letter-spacing: 1.8px;line-height: 1.8;box-sizing: border-box;"
              powered-by="xiumi.us"><p style="white-space: normal;box-sizing: border-box;"><br></p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(230, 179, 34);"><strong><span
                style="font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">高鹏：</span></strong></span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">目前的艺术教育，很大程度都是以造型思维培养为主，基本还是延用徐悲鸿先生建立的教育思想。改革开放后，现、当代艺术迅速被介绍到中国，目前又受到了全球数字化，虚拟化的冲击，所以学院都曾经无所适从，老师不知道该怎么教学生？现如今大家又面临一个新的艺术课题和方向，这个方向从传统的造型艺术、概念艺术，走向了一种数字思维。</span>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);"><br></span>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><strong><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">数字世界的到来让人的整个思维基础模型和架构发生了巨大的改变，这也是我曾经在今日做未来馆的数字艺术时的一个最大感知改变。</span></strong><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">时代发生改变了，整个艺术教育的基本根基也应该发生改变，会从造型思维，观念思维，导向培养基本数字思维的过程。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">当然，在未来的数字世界中更需要需要一些准则和社会责任，艺术家不光是一个社会的参与者和探讨者，必须要有基本社会责任感。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">如果没有社会责任感，未来的数字世界会更为混乱的。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">所以，具有前瞻性的基础教育变得尤为重要。</span>
              </p></section>
          </section>
        </section>
        <section style="box-sizing: border-box;" powered-by="xiumi.us">
          <section style="display: flex;flex-flow: row nowrap;box-sizing: border-box;">
            <section
              style="display: inline-block;vertical-align: middle;width: auto;flex: 0 0 0%;align-self: center;height: auto;padding-right: 10px;padding-left: 10px;box-sizing: border-box;line-height: 0;">
              <section style="line-height: 0;width:0;">
                <svg viewBox="0 0 1 1" style="vertical-align:top;"></svg>
              </section>
            </section>
            <section
              style="display: inline-block;vertical-align: middle;width: auto;align-self: center;flex: 100 100 0%;box-sizing: border-box;line-height: 0;">
              <section style="line-height: 0;width:0;">
                <svg viewBox="0 0 1 1" style="vertical-align:top;"></svg>
              </section>
            </section>
          </section>
        </section>
        <section style="box-sizing: border-box;" powered-by="xiumi.us">
          <section style="display: flex;flex-flow: row nowrap;box-sizing: border-box;">
            <section
              style="display: inline-block;vertical-align: middle;width: auto;flex: 0 0 0%;align-self: center;height: auto;padding-right: 10px;padding-left: 10px;box-sizing: border-box;line-height: 0;">
              <section style="line-height: 0;width:0;">
                <svg viewBox="0 0 1 1" style="vertical-align:top;"></svg>
              </section>
            </section>
            <section
              style="display: inline-block;vertical-align: middle;width: auto;align-self: center;flex: 100 100 0%;box-sizing: border-box;line-height: 0;">
              <section style="line-height: 0;width:0;">
                <svg viewBox="0 0 1 1" style="vertical-align:top;"></svg>
              </section>
            </section>
          </section>
        </section>
      </section>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <br><span
        style="max-width: 100%;font-family: Optima-Regular, PingFangTC-light;letter-spacing: 1.5px;color: rgb(123, 127, 131);font-size: 12px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"></span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"></span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <img data-ratio="0.6665"
             data-src="https://mmbiz.qpic.cn/mmbiz_jpg/xIYMgH7g8Q5fSXTMvwiaJyeJibsjAz1DAXx71ODOnicTC854XyE2htols6x9uGUhiaK2PybVBCoUyicZKKcB8PbiaBXg/640?wx_fmt=jpeg"
             data-type="jpeg" data-w="2000" title="6.2019年，世界图像：徐冰《蜻蜓之眼》" data-backw="546" data-backh="364"
             style="width: 645px !important; height: 430.56px !important;" _width="100%" class="img_loading"
             src="./imgs/5.webp.jpg"
             crossorigin="anonymous"></p>
      <p
        style="text-align: center;margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="text-align: center;max-width: 100%;font-family: Optima-Regular, PingFangTC-light;letter-spacing: 1.5px;color: rgb(123, 127, 131);font-size: 12px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;">2019年，世界图像：徐冰《蜻蜓之眼》</span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <br></p>
      <section
        style="font-size: 15px;font-family: PingFangSC-light;padding-right: 8px;padding-left: 8px;box-sizing: border-box;">
        <section style="box-sizing: border-box;" powered-by="xiumi.us">
          <section style="display: flex;flex-flow: row nowrap;box-sizing: border-box;">
            <section
              style="display: inline-block;vertical-align: middle;width: auto;flex: 0 0 0%;align-self: center;height: auto;padding-right: 10px;padding-left: 10px;box-sizing: border-box;">
              <section
                style="transform: rotateZ(45deg);-webkit-transform: rotateZ(45deg);-moz-transform: rotateZ(45deg);-o-transform: rotateZ(45deg);box-sizing: border-box;"
                powered-by="xiumi.us">
                <section
                  style="text-align: center;font-size: 0px;margin-right: 0%;margin-left: 0%;box-sizing: border-box;">
                  <section
                    style="display: inline-block;width: 8px;height: 8px;vertical-align: top;overflow: hidden;border-style: solid;border-width: 2px;border-radius: 0px;border-color: rgb(230, 179, 34);box-shadow: rgba(255, 255, 255, 0) 2px -2px 0px;background-color: rgba(230, 179, 34, 0.07);box-sizing: border-box;line-height: 0;">
                    <br></section>
                </section>
              </section>
            </section>
            <section
              style="display: inline-block;vertical-align: middle;width: auto;align-self: center;flex: 100 100 0%;box-sizing: border-box;">
              <section style="text-align: left;color: rgb(206, 167, 20);letter-spacing: 1px;box-sizing: border-box;"
                       powered-by="xiumi.us"><p style="box-sizing: border-box;"><strong><span
                style="color: rgb(230, 179, 34);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">艺术头条：想象力、创造力，一直以来都是艺术教育领域在探讨的问题，您觉得基础教育该如何面对这个问题？</span></strong>
              </p></section>
            </section>
          </section>
        </section>
        <section
          style="display: inline-block;width: 100%;vertical-align: top;border-width: 0px;padding-left: 14px;letter-spacing: 0px;box-sizing: border-box;"
          powered-by="xiumi.us">
          <section
            style="display: inline-block;width: 100%;vertical-align: top;border-left: 1px solid rgb(230, 179, 34);border-bottom-left-radius: 0px;padding-top: 6px;padding-bottom: 20px;padding-left: 13px;letter-spacing: 0px;box-sizing: border-box;"
            powered-by="xiumi.us">
            <section
              style="font-size: 14px;color: rgb(84, 75, 110);letter-spacing: 1.8px;line-height: 1.8;box-sizing: border-box;"
              powered-by="xiumi.us"><p style="white-space: normal;box-sizing: border-box;"><br></p>
              <p style="white-space: normal;box-sizing: border-box;"><span style="color: rgb(230, 179, 34);"><strong
                style="letter-spacing: 1.8px;"><span
                style="font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">高鹏：</span></strong></span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">创造力缺失源于基础思维模型、结构的问题，不在这种创造力和开放性教育系统当中出来的学生，要求他们做创造力的事情，是不太可能去突破的。同时，他们也很难去理解，甚至尊重创造的过程。而现阶段正需要我们重新审视到底什么是创造力？如何去培养创造力？</span><br>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);"><br></span>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><strong><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">无疑，艺术和设计是关于创造力的学科。</span></strong><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">老师不应该框定艺术与设计的一套方法和一个具体的结果，必须在不断地培养和不确定中去挖掘学生创造力可能性。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">这个过程中不能直接给学生一个明确的“成功学”方法。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">在我的设想里，不同领域的学者，老师以之为前提，共同讨论设计不同的课程框架，呈现不同的教育方式。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">这些都和老师们的阅历、学识、眼界、品味有关。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">很多学科和艺术虽然探索方式不同，但是本质上都是探寻真理和秩序，洞察宇宙和人心的奥秘。</span>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);"><br></span>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">中国需要这么一群学者，老师，他们站在那里就代表着中国艺术设计教育的希望，代表着中国艺术设计教育的水平。</span>
              </p></section>
          </section>
        </section>
        <section style="box-sizing: border-box;" powered-by="xiumi.us">
          <section style="display: flex;flex-flow: row nowrap;box-sizing: border-box;">
            <section
              style="display: inline-block;vertical-align: middle;width: auto;flex: 0 0 0%;align-self: center;height: auto;padding-right: 10px;padding-left: 10px;box-sizing: border-box;">
              <section
                style="transform: rotateZ(45deg);-webkit-transform: rotateZ(45deg);-moz-transform: rotateZ(45deg);-o-transform: rotateZ(45deg);box-sizing: border-box;"
                powered-by="xiumi.us">
                <section
                  style="text-align: center;font-size: 0px;margin-right: 0%;margin-left: 0%;box-sizing: border-box;">
                  <section
                    style="display: inline-block;width: 8px;height: 8px;vertical-align: top;overflow: hidden;border-style: solid;border-width: 2px;border-radius: 0px;border-color: rgb(230, 179, 34);box-shadow: rgba(255, 255, 255, 0) 2px -2px 0px;background-color: rgba(230, 179, 34, 0.07);box-sizing: border-box;line-height: 0;">
                    <br></section>
                </section>
              </section>
            </section>
            <section
              style="display: inline-block;vertical-align: middle;width: auto;align-self: center;flex: 100 100 0%;box-sizing: border-box;">
              <section style="text-align: left;color: rgb(206, 167, 20);letter-spacing: 1px;box-sizing: border-box;"
                       powered-by="xiumi.us"><p style="box-sizing: border-box;"><strong><span
                style="color: rgb(230, 179, 34);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">艺术头条：那您对接下来的工作有怎样的具体规划呢？最大的挑战是什么？</span></strong>
              </p></section>
            </section>
          </section>
        </section>
        <section
          style="display: inline-block;width: 100%;vertical-align: top;border-width: 0px;padding-left: 14px;letter-spacing: 0px;box-sizing: border-box;"
          powered-by="xiumi.us">
          <section
            style="display: inline-block;width: 100%;vertical-align: top;border-left: 1px solid rgb(230, 179, 34);border-bottom-left-radius: 0px;padding-top: 6px;padding-bottom: 20px;padding-left: 13px;letter-spacing: 0px;box-sizing: border-box;"
            powered-by="xiumi.us">
            <section
              style="font-size: 14px;color: rgb(84, 75, 110);letter-spacing: 1.8px;line-height: 1.8;box-sizing: border-box;"
              powered-by="xiumi.us"><p style="white-space: normal;box-sizing: border-box;"><br></p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(230, 179, 34);"><strong><span
                style="font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">高鹏：</span></strong></span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">首先，学校成立了“北京师范大学未来设计创新研究中心”简称“未来设计中心”（FDC），中心是人文社科高等研究院下设的研究型实体，中心将工作根植于科技与艺术的交叉领域，通过在科技，艺术，人文，社科等领域广泛的跨界合作，形成学科互补的学术研究。另外，中心承担筹建“北京师范大学未来设计学院”的工作，会先从研究生培养开始，明年正式招收艺术硕士。</span>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);"><br></span>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">目前，为中心规划了“未来生活方式”、“未来艺术与科技”、“未来艺术设计教育”三个研究和教学方向。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">比如在“未来生活方式”方面，面向未来的文化形态，具体课程会包括东西方的传统手工艺，时尚生活设计，产品设计，空间与环境设计，信息传播与可视化设计等。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">在“未来科技与艺术设计”专业方向，会有AI人工智能设计应用，新媒体交互设计，认知学科等领域，对接国际前沿学科，创一流学术研究成果。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">在“未来艺术设计教育”方面，会重点研发18岁以下的设计思维课程。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">目前中心已经聘请了7位不同领域的国内外资深专家和我一同工作。</span>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);"><br></span>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><strong><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);"><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">最大挑战是打破固有的思维模式，进行跨学科</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">研究的磨合。</span></span></strong><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);"><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);"></span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">因为好多学者所谈的AI和我们以前在艺术角度理解的AI是不一样的，有一些湾区香港，澳门大学过来的教授，他们讨论科技，他们讨论的机器人，和我们自己站在艺术角度的理解是很不一样的。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">不过，这对我来说是一个好事，完全站在一个不同的平台和领域去思考艺术设计教育这件事。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">必须要突破自己的思维局限，因为大家既需要已有的经验范畴里工作，又需要不断地打破固有经验。</span></span>
              </p></section>
          </section>
        </section>
      </section>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <br></p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"></span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <img data-ratio="1.026"
             data-src="https://mmbiz.qpic.cn/mmbiz_jpg/xIYMgH7g8Q5fSXTMvwiaJyeJibsjAz1DAX4p1Jow9Kcg29MVYxq7qmA4P57UxfYmTYEtuIqzzVWTlW0f6xkgZJVQ/640?wx_fmt=jpeg"
             data-type="jpeg" data-w="2000"
             style="max-width: 600px; width: 100% !important; height: auto !important; visibility: visible !important;"
             title="5.今日美术馆“Future云端馆”APP截屏5.今日美术馆“Future云端馆”APP截屏" data-backw="600" data-backh="616" _width="100%"
             class=""
             src="./imgs/6.webp.jpg"
             crossorigin="anonymous" data-fail="0"></p>
      <p
        style="text-align: center;margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;font-family: Optima-Regular, PingFangTC-light;letter-spacing: 1.5px;font-size: 12px;color: rgb(123, 127, 131);box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;">今日美术馆“Future云端馆”APP截屏5.今日美术馆“Future云端馆”APP截屏</span>
      </p>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <br></p>
      <section
        style="font-size: 15px;font-family: PingFangSC-light;padding-right: 8px;padding-left: 8px;box-sizing: border-box;">
        <section style="box-sizing: border-box;" powered-by="xiumi.us">
          <section style="display: flex;flex-flow: row nowrap;box-sizing: border-box;">
            <section
              style="display: inline-block;vertical-align: middle;width: auto;flex: 0 0 0%;align-self: center;height: auto;padding-right: 10px;padding-left: 10px;box-sizing: border-box;">
              <section
                style="transform: rotateZ(45deg);-webkit-transform: rotateZ(45deg);-moz-transform: rotateZ(45deg);-o-transform: rotateZ(45deg);box-sizing: border-box;"
                powered-by="xiumi.us">
                <section
                  style="text-align: center;font-size: 0px;margin-right: 0%;margin-left: 0%;box-sizing: border-box;">
                  <section
                    style="display: inline-block;width: 8px;height: 8px;vertical-align: top;overflow: hidden;border-style: solid;border-width: 2px;border-radius: 0px;border-color: rgb(230, 179, 34);box-shadow: rgba(255, 255, 255, 0) 2px -2px 0px;background-color: rgba(230, 179, 34, 0.07);box-sizing: border-box;line-height: 0;">
                    <br></section>
                </section>
              </section>
            </section>
            <section
              style="display: inline-block;vertical-align: middle;width: auto;align-self: center;flex: 100 100 0%;box-sizing: border-box;">
              <section style="text-align: left;color: rgb(206, 167, 20);letter-spacing: 1px;box-sizing: border-box;"
                       powered-by="xiumi.us"><p style="box-sizing: border-box;"><strong><span
                style="color: rgb(230, 179, 34);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">艺术头条：为什么选择到珠海？</span></strong>
              </p></section>
            </section>
          </section>
        </section>
        <section
          style="display: inline-block;width: 100%;vertical-align: top;border-width: 0px;padding-left: 14px;letter-spacing: 0px;box-sizing: border-box;"
          powered-by="xiumi.us">
          <section
            style="display: inline-block;width: 100%;vertical-align: top;border-left: 1px solid rgb(230, 179, 34);border-bottom-left-radius: 0px;padding-top: 6px;padding-bottom: 20px;padding-left: 13px;letter-spacing: 0px;box-sizing: border-box;"
            powered-by="xiumi.us">
            <section
              style="font-size: 14px;color: rgb(84, 75, 110);letter-spacing: 1.8px;line-height: 1.8;box-sizing: border-box;"
              powered-by="xiumi.us"><p style="white-space: normal;box-sizing: border-box;"><br></p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(230, 179, 34);"><strong><span
                style="font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">高鹏：</span></strong></span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">选择珠海是因为，2019年4月教育部正式批准北京师范大学在大湾区珠海建设南方校区。也是响应国家“一带一路”倡议、粤港澳大湾区建设和疏解北京非首都功能等重大任务。所以北京师范大学以后是以北京校区和珠海校区的“一体两翼”办学格局，打造和北京校区同一水平，统一师资的南方校区。</span>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);"><br></span>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">而且，珠海校区要求更高，创新实践很多之前无法完成的教学改革，实现师大一直以来的教学理想。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">目前要求我们“高标准、新机制、国际化”，珠海校区已经建设了未来教育学院，一带一路学院等，正在筹建未来设计学院。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">目标是打造中国基础教育的“黄埔军校”，推进学科交叉创新，助力粤港澳大湾区融合发展，进一步强化服务国家基础教育改革。</span>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);"><br></span>
              </p>
              <p style="white-space: normal;box-sizing: border-box;"><strong><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">这也是我第一次长期在南方生活，算是一次重大的生活决定。</span></strong><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">但是，我很看好大湾区的未来发展。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">美术馆的工作经历，让我愈发感受到基础美育的重要性，在珠海校区有很多新机制，我的很多教育想法得到大力的支持和鼓励。</span><span
                style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;background-color: rgb(255, 255, 255);">艺术教育是根本，设计可以更好地拉动大湾区的产业发展，这是我愿意做的方向，这也是整个大湾区希望北京师范大学培养的方向。</span>
              </p></section>
          </section>
        </section>
        <section style="box-sizing: border-box;" powered-by="xiumi.us">
          <section style="display: flex;flex-flow: row nowrap;box-sizing: border-box;">
            <section
              style="display: inline-block;vertical-align: middle;width: auto;flex: 0 0 0%;align-self: center;height: auto;padding-right: 10px;padding-left: 10px;box-sizing: border-box;line-height: 0;">
              <section style="line-height: 0;width:0;">
                <svg viewBox="0 0 1 1" style="vertical-align:top;"></svg>
              </section>
            </section>
            <section
              style="display: inline-block;vertical-align: middle;width: auto;align-self: center;flex: 100 100 0%;box-sizing: border-box;line-height: 0;">
              <section style="line-height: 0;width:0;">
                <svg viewBox="0 0 1 1" style="vertical-align:top;"></svg>
              </section>
            </section>
          </section>
        </section>
      </section>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"></span><br>
      </p>
      <section
        style="max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);margin-left: 16px;margin-right: 16px;box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;">后记：</span><span
        style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;">从6岁开始与艺术打交道，时间即将来到“不惑”之年的高鹏重新出发，往后的岁月愿做艺术的摆渡人，把基础美术教育当作终极目标，向中国乃至全球持续的输出未来型艺术人才。</span><br>
      </section>
      <section
        style="max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);margin-left: 16px;margin-right: 16px;box-sizing: border-box !important;word-wrap: break-word !important;">
        <br></section>
      <section style="box-sizing: border-box;margin-left: 16px;margin-right: 16px;">
        <section
          style="display: flex;flex-flow: row nowrap;margin: 15px 0% -20px;text-align: left;justify-content: flex-start;transform: translate3d(-9px, 0px, 0px);-webkit-transform: translate3d(-9px, 0px, 0px);-moz-transform: translate3d(-9px, 0px, 0px);-o-transform: translate3d(-9px, 0px, 0px);box-sizing: border-box;">
          <section
            style="display: inline-block;vertical-align: top;width: auto;align-self: flex-start;flex: 0 0 0%;height: auto;box-sizing: border-box;">
            <section
              style="text-align: center;font-size: 0px;transform: translate3d(6px, 0px, 0px);margin-top: -8px;margin-right: 0%;margin-left: 0%;box-sizing: border-box;"
              powered-by="xiumi.us">
              <section
                style="display: inline-block;width: 14px;height: 24px;vertical-align: top;overflow: hidden;background-color: rgb(222, 177, 48);box-shadow: rgb(255, 255, 255) 0px 0px 0px;border-style: solid;border-width: 3px;border-radius: 0px;border-color: rgb(255, 255, 255);box-sizing: border-box;line-height: 0;">
                <br></section>
            </section>
          </section>
          <section
            style="display: inline-block;vertical-align: top;width: auto;background-color: rgb(246, 246, 246);flex: 0 0 auto;align-self: flex-start;min-width: 10%;max-width: 100%;height: auto;box-shadow: rgb(0, 0, 0) 0px 0px 0px;border-right: 3px solid rgb(255, 255, 255);border-top-right-radius: 0px;box-sizing: border-box;">
            <section
              style="transform: translate3d(4px, 0px, 0px);-webkit-transform: translate3d(4px, 0px, 0px);-moz-transform: translate3d(4px, 0px, 0px);-o-transform: translate3d(4px, 0px, 0px);box-sizing: border-box;"
              powered-by="xiumi.us">
              <section
                style="text-align: justify;padding-right: 17px;padding-left: 17px;color: rgb(230, 179, 34);letter-spacing: 1px;line-height: 2;box-sizing: border-box;">
                <p style="white-space: normal;box-sizing: border-box;"><strong
                  style="box-sizing: border-box;">高鹏简历：</strong></p></section>
            </section>
          </section>
        </section>
      </section>
      <section
        style="font-size: 15px;font-family: PingFangSC-light;padding-right: 8px;padding-left: 8px;box-sizing: border-box;margin-left: 16px;margin-right: 16px;">
        <section
          style="display: inline-block;width: 100%;vertical-align: top;background-color: rgba(255, 255, 255, 0);border-style: solid;border-width: 1px;border-radius: 0px;border-color: rgb(240, 240, 240);padding: 30px 20px 20px;box-sizing: border-box;"
          powered-by="xiumi.us">
          <section
            style="font-size: 14px;color: rgb(88, 88, 88);line-height: 1.8;letter-spacing: 1px;box-sizing: border-box;"
            powered-by="xiumi.us"><p style="white-space: normal;box-sizing: border-box;"><span
            style="font-size: 13px;background-color: rgb(255, 255, 255);color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;letter-spacing: 1.5px;">现任“北京师范大学人文社科高等研究院”研究员，“中国博物馆协会美术馆专业委员会”理事，“中央美术学院”理事，“今日美术馆”荣誉馆长。<br></span>
          </p>
            <p style="white-space: normal;box-sizing: border-box;"><span
              style="color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;letter-spacing: 1.5px;font-size: 13px;"><br></span>
            </p>
            <p style="white-space: normal;box-sizing: border-box;"><span
              style="font-size: 13px;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;letter-spacing: 1.5px;">先后就读于中央美术学院，伦敦艺术大学，获得本科至博士学位，北京大学博士后。曾任“2008年北京奥林匹克运动会组织委员会”景观副经理，2015年达沃斯经济论坛“全球杰出青年”联席主席，获“全球杰出青年-艺术使者”称号，2015年“北京五四奖章”获得者。</span>
            </p></section>
        </section>
      </section>
      <section
        style="max-width: 100%;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);margin-left: 16px;margin-right: 16px;box-sizing: border-box !important;word-wrap: break-word !important;">
        <span
          style="max-width: 100%;color: rgb(0, 0, 0);font-family: Optima-Regular, PingFangTC-light;font-size: 15px;letter-spacing: 1.5px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"><br></span>
      </section>
      <p
        style="margin-right: 16px;margin-left: 16px;max-width: 100%;min-height: 1em;color: rgba(0, 0, 0, 0.8);font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif;letter-spacing: 0.544px;white-space: normal;background-color: rgb(255, 255, 255);text-align: center;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;">
        <em
          style="max-width: 100%;color: rgb(123, 127, 131);font-size: 13px;letter-spacing: 0.544px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;"><span
          style="max-width: 100%;font-size: 12px;letter-spacing: 0.544px;box-sizing: border-box !important;word-wrap: break-word !important;overflow-wrap: break-word !important;">-&nbsp;END -</span></em>
      </p>

    </div>
  </div>
</template>

<script>
  export default {
    name: "news1"
  }
</script>

<style scoped>
  body{
    font-family: -apple-system-font,BlinkMacSystemFont,"Helvetica Neue","PingFang SC","Hiragino Sans GB","Microsoft YaHei UI","Microsoft YaHei",Arial,sans-serif;
  }

  .rich_media_title {
    text-align: center;
    font-weight: 500;
    font-size: 22px;
    line-height: 1.4;
    margin-bottom: 14px;
  }
</style>
