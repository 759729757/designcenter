<template>
    <div>
<!--      <h2 class="section-title">学习经历</h2>-->
      <div class="container-sm">
        <h2>Miriam Mirolla</h2>
        <strong>未来理论、艺术心理方向带头人</strong>
        <p>
          职称：教授 <br>
          研究领域：艺术史论、当代艺术、交互理论和应用技术
        </p>
        <strong>代表著作</strong>
        <table>
          <tr>
            <td>序号</td><td>本人排序</td><td>年份</td><td>著作名称</td>
            <td>出版单位</td>
          </tr>
          <tr>
            <td>1</td><td>1</td><td>2020</td><td>“Lo Specchio Tachistoscopico con Stimolazione a Sognare. Scritti ed Esperimenti” </td>
            <td>LAP Editions, Roma.</td>
          </tr>
          <tr>
            <td>2</td><td>1</td><td>2019</td><td>“L’arte che anticipa il futuro” </td>
            <td>Lap Editions, Beijing.</td>
          </tr>
          <tr>
            <td>3</td><td>1</td><td>2008</td><td>"Love and Psyche. Storyboard of a myth " </td>
            <td>Electa, Milan.</td>
          </tr>
          <tr>
            <td>4</td><td>1</td><td>2002</td><td>"Art and History of Art. The Twentieth Century"</td>
            <td>Minerva Italica, Milan.</td>
          </tr>
          <tr>
            <td>5</td><td>1</td><td>1995</td><td>"Sergio Lombardo" </td><td>Laboratory Museum of Contemporary Art, La Sapienza University, Rome.</td>
          </tr>
          <tr>
            <td>6</td><td>1</td><td>2019</td><td>“Contemporary Art, from 1945 to today" </td>
            <td>BTS School of Continuing Education of the Italy-China Foundation, Chongqing.</td>
          </tr>
          <tr>
            <td>7</td><td>1</td><td>2006</td><td>"L'arte c'est moi. 15 interviews on contemporary art "
            "Contemporary Italian Experimental Art: Devices of Visual Subtraction"
          </td><td>Avagliano Ed., Rome.</td>
          </tr>
          <tr>
            <td>8</td><td>1</td><td>1995</td><td>"From Dadaism to Inventualism: Portrait as an Experiment"</td>
            <td>University of Tuscia, Faculty of Conservation of Cultural Heritage, "La Sapienza" University of Rome, Lithos Editrice, Rome.</td>
          </tr>
          <tr>
            <td>9</td><td></td><td>2011</td><td>"Contemporary Italian Experimental Art: Devices of Visual Subtraction”</td>
            <td>Ministry of Culture of the Russian Federation, State Institute for Art Studies, Moscow.</td>
          </tr>
          <tr>
            <td>10</td><td>1</td><td>2017</td><td>Contemporaneità del ritratto dal Futurismo all’Eventualismo</td>
            <td>Maretti Editore</td>
          </tr>
        </table>
        <strong>代表论文</strong>
        <table>
          <tr>
            <td>序号</td><td>年份</td><td>题目</td><td>期刊名称</td><td>卷期</td><td>页码</td>
          </tr>
          <tr>
            <td>1</td><td>2019</td><td>“Underground Eventualista. La ricerca estetica in Italia 1972-2019”</td>
            <td>Rivista di Psicologia dell'Arte, Jartrakor Editions, Rome</td><td>New  Series year XXXIX, n.29</td><td></td>
          </tr>
          <tr>
            <td>2</td><td>2015</td><td>"Eye movements in the perception of a stochastic image" </td>
            <td>Rivista di Psicologia dell’Arte, Jartrakor Editions, Rome</td><td>New series, year XXXVIn.26.</td><td></td>
          </tr>
          <tr>
            <td>3</td><td>2017</td><td>“Tutto in casa. Collezione di famiglia”, The Rubell Collection and Foundation in Miami</td>
            <td>ARTE. Editoriale Giorgio Mondadori</td><td>Sept, 2017, N.529</td><td>132-136</td>
          </tr>
          <tr>
            <td>4</td><td>2018</td><td>Museo aperto: ICA a Miami.</td><td>ARTE. Editoriale Giorgio Mondadori</td>
            <td>Feb.2018</td><td></td>
          </tr>
          <tr>
            <td>5</td><td>2014</td><td>“Come edificarsi un museo. Colloquio con Jorge M.Perez”, The PAMM Museum in Miami</td>
            <td>Il Sole 24 Ore</td><td>Domenica, 11 maggio 2014, n.128</td><td>24</td>
          </tr>
          <tr>
            <td>6</td><td>2017</td><td>Nel Museo di Mr.Wong</td><td>ARTE. Editoriale Giorgio Mondadori</td><td>Feb.2017, N.522</td><td></td>
          </tr>
          <tr>
            <td>7</td><td>2015</td><td>L’arte di costruire significati. A colloquio con Emi Fontana</td><td>Il Sole 24 Ore</td>
            <td></td><td></td>
          </tr>
          <tr>
            <td>8</td><td>2016</td><td>Il proprio Guanxi al servizio di tutti. A colloquio con George Wong</td><td>Il Sole 24 Ore</td>
            <td>Domenica, 4 Dicembre 2016, n.333</td><td></td>
          </tr>
          <tr>
            <td>9</td><td>2016</td><td>La casa delle opere che dialogano</td><td>Il Sole 24 Ore</td><td></td><td></td>
          </tr>
          <tr>
            <td>10</td><td>2020</td><td>Astenersi o esprimersi, questo è il dilemma</td><td>CINITALIA</td><td>Anno 2020, n.236</td><td>70-75</td>
          </tr>
        </table>
        <strong>学术交流</strong>
        <p>
          1994年，伦敦意大利学院史密斯美术馆“四位意大利当代艺术大师在伦敦”展（Four Italian Masters of Contemporary Art in London）
          <br>1999年，伦敦温布尔登视觉艺术学院“一些心理刺激”展（Some Psychological Stimula）.
          <br>2012年，意大利罗马ABA“视觉文化与女性研究之间的爱与心理问题”大会 （Amore e Psiche tra Visual Cultures e Women Studies）
          <br>2017年，北京意大利驻华大使馆“预见未来艺术——意大利前卫艺术理论及作品”展（L’Arte che anticipa il futuro. Teorie e opere dell’Avanguardia Italiana, dal Futurismo all’Eventualismo）
          <br> 2017年，德国伍珀塔尔大学第19届国际眼动大会Sergio Lombardo “20个随机图像上的凝视路径 ”展（20 Gaze Paths on a Stochastic Image by Sergio Lombardo”, 19th International Congress on Eye Movements）.
          <br> 2017年，美国佛罗里达大西洋大学计算机电气工程和计算机科学系“艺术实验”展（Experiments in Art）
          <br> 2018年，意大利罗马但丁协会举办的德国仲裁协会“艺术及替代性纠纷解决机制”大会（”Art & Alternative Dispute Resolution”,  DIS German Arbitration Institute, Società Dante Alighieri）
          <br> 2018年，北京朱乃正艺术研究中心与曹兴元“艺术、非艺术和反艺术”交流会（Art, Non-Art and Anti-Art - Revisit Marcel Duchamp）
          <br>2018年9月10-15日，意大利罗马大学心理学和药学学院第7届空间认知国际会议（7th International Conference on Spatial Cognition）“Diana and Actaeon. An eye tracking study on old mythology”, ICSC, Rome, 10-15 Settembre
          <br>2018年，北京意大利驻华大使馆、永安会计师事务所、意中基金会 “意大利文化遗产投资”展（Investment in Cultural Heritage in Italy）
          <br>2019年，意大利罗马当代艺术博物馆“1972-2019年意大利美学研究之情境主义研究”（Eventualism Underground Eventualista. Italian Aesthetic Research 1972-2019）
          <br> 2019年，北京今日美术馆“蜻蜓之眼”（Dragonfly Eyes）艺术展
          <br>2019年，美国佛罗里达国际大学“艺术心理学和情境主义”展
          <br>2020年，意大利罗马音乐公园基金会礼堂（Auditorium Fondazione Parco della Musica）“意大利心理学”展
        </p>

      </div>
    </div>
</template>

<script>
    export default {
        name: "gaopeng"
    }
</script>

<style scoped>
  table{text-align: center;border-collapse: collapse;width: 100%;margin: 20px 0;}
  td{padding: 10px;border: #000 solid 1px;}
</style>
