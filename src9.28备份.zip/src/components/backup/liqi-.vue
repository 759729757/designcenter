<template>
    <div>
<!--      <h2 class="section-title">学习经历</h2>-->
      <div class="container-sm">
        <h2>李琦</h2>
        <strong>科技艺术带头人</strong>
        <p>
          职称：教授 <br>
          研究领域：数字地球、智慧城市系统与认知计算、大气污染与人体健康<br>
          · 率先提出“数字城市”概念，其理论、方法与关键技术在“数字北京”和“数字上海”整体实施，“数字北京”2001年上线运行，支撑了2008年奥运会等重大活动的成功举办及城市的高效、安全运行<br>
          · 有丰富的国家级大型课题经验<br>
          · 获国家、省部级科技进步奖12项<br>
        </p>

      </div>
    </div>
</template>

<script>
    export default {
        name: "gaopeng"
    }
</script>

<style scoped>
  table{text-align: center;border-collapse: collapse;width: 100%;margin: 20px 0;}
  td{padding: 10px;border: #000 solid 1px;}
</style>
